#ifndef TIME_H
#define TIME_H
extern int matchTime(unsigned char p_type,int index);
extern int setTime(int second);
#define E8  28800       // 8*3600

#endif // TIME_H
